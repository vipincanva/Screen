export function PicoBadge() {
  return (
    <>
      <span></span>
    </>
  );
}
